CREATE PROCEDURE PROC_GET_RESOURCE_LOCK(
	newLockId IN LONG, 
	userId IN LONG, 
	lFrom IN VARCHAR2, 
	loginTime IN LONG, 
	moduleId IN VARCHAR2, 
	resourceId IN LONG, 
	action IN INTEGER,
	lockTime IN LONG,
	expireTime IN LONG,
	success OUT INTEGER
) IS
	
		lockId LONG;
		ownerId LONG;
		curExpireTime LONG;
		lockAction INTEGER;
		loginFrom VARCHAR2(100);
	
	begin
		success := 0;

		BEGIN

		if(action <> -1)
			then
				select ID,OWNER,EXPIREATION_TIMEMILLIS,LOGIN_FROM,ACTION into lockId, ownerId,curExpireTime,loginFrom,lockAction from ctp_lock where RESOURCE_ID=resourceId and (ACTION=action or ACTION=-1);
			else
				select ID,OWNER,EXPIREATION_TIMEMILLIS,LOGIN_FROM,ACTION into lockId, ownerId,curExpireTime,loginFrom,lockAction from ctp_lock where RESOURCE_ID=resourceId;
		end if;
		
		EXCEPTION WHEN NO_DATA_FOUND THEN
			null;
		END;
		
		BEGIN
		
		if(lockId is null)
			then 			
				insert into ctp_lock(ID,OWNER,MODULE,RESOURCE_ID,ACTION,LOGIN_TIMEMILLIS,LOCK_TIMEMILLIS,EXPIREATION_TIMEMILLIS,LOGIN_FROM)VALUES(newLockId,userId,moduleId,resourceId,action,loginTime,lockTime,expireTime,lFrom);
				success := 1;
			else
				if(ownerId = userId and lFrom = loginFrom)
					then 
						update ctp_lock set LOGIN_TIMEMILLIS=loginTime,LOCK_TIMEMILLIS=lockTime,EXPIREATION_TIMEMILLIS=expireTime,ACTION=action where ID=lockId;
						success := 1;
					else
						if(curExpireTime < lockTime)
							then
								delete from ctp_lock where ID=lockId;
								insert into ctp_lock(ID,OWNER,MODULE,RESOURCE_ID,ACTION,LOGIN_TIMEMILLIS,LOCK_TIMEMILLIS,EXPIREATION_TIMEMILLIS,LOGIN_FROM)VALUES(newLockId,userId,moduleId,resourceId,action,loginTime,lockTime,expireTime,lFrom);
								success := 1;
							else
								success := 0;
						end if;
				end if;
		end if;
		commit;
		EXCEPTION WHEN OTHERS THEN
			success := 0;
			rollback;
		END;
			
	end PROC_GET_RESOURCE_LOCK;
/

