CREATE procedure proc_meetting_check_delAndSave(p in varchar2)
is
  v_mday FORMSON_0028.field0007%type;
  v_i number := 1;
  v_id number ;
  v_FORMMAIN_ID formmain_0027.id%type;
  v_FIELD0019 formmain_0027.field0017%type;
  v_FIELD0020 formmain_0027.field0002%type;
  v_sort number;
  v_randomv number;
  v_random2 number;
  begin
    delete from FORMSON_0028 where to_char(field0007,'yyyy-MM-dd') < to_char(sysdate,'yyyy-MM-dd') and field0029=p;
    commit;
    select ((select max(field0007) from FORMSON_0028 where  field0029=p)+0) into v_mday from dual;
    select (select max(sort) from FORMSON_0028 where  field0029=p) into v_sort from dual;
    --给字段赋值从父表中查询
    SELECT (TO_NUMBER(sysdate - TO_DATE('1970-01-01 8:0:0', 'YYYY-MM-DD HH24:MI:SS')) * 24 * 60 * 60 * 1000) into v_id FROM DUAL;
    select id into v_FORMMAIN_ID from formmain_0027 where rownum=1 and field0001 =p;
    select field0017 into v_FIELD0019 from formmain_0027 where rownum=1 and field0001 =p;
    select field0002 into v_FIELD0020 from formmain_0027 where rownum=1 and field0001 =p;
    --select to_number(substr(to_char(systimestamp, 'yyyymmddhh24missff'),2)) into v_randomv from dual;
    select  FLOOR(DBMS_RANDOM.VALUE(1,1000)) into v_randomv from dual;
    select  FLOOR(DBMS_RANDOM.VALUE(1,10000)) into v_random2 from dual;
    for v_i in 1..3 loop
      insert into FORMSON_0028
      (ID,FORMMAIN_ID,SORT,FIELD0007,FIELD0010,FIELD0012,FIELD0013,FIELD0019,FIELD0020,FIELD0021,FIELD0029)
      values(to_number(v_randomv||v_random2||v_sort+v_i||p),v_FORMMAIN_ID,v_sort+v_i,v_mday+v_i,p,'-3354720569401522387','-3354720569401522387',v_FIELD0019,v_FIELD0020,0,p);
      commit;
    end loop;
    end;
/

