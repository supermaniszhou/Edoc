CREATE TRIGGER TR_CONTRACT
  BEFORE INSERT
  ON CONTRACT
  FOR EACH ROW
  declare tempnum number; begin select SEQ_Contract.nextval into tempnum from dual; :new.ID :=tempnum; end;
/

