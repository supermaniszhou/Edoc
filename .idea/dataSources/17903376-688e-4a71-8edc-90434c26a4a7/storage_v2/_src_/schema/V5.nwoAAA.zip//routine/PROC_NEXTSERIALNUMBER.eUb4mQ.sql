CREATE PROCEDURE proc_nextserialnumber (
    sid        IN INTEGER,
    readonly   IN INTEGER,
    rnextval   OUT INTEGER
) IS

    svalue             INTEGER;
    rulreset           INTEGER;
    minval             INTEGER;
    todbval            INTEGER;
    maxval             INTEGER;
    digitnum           INTEGER;
    currentyear        INTEGER;
    currentmonth       INTEGER;
    currentday         INTEGER;
    markyear           INTEGER;
    markmonth          INTEGER;
    markday            INTEGER;
    scurrentmarkdate   DATE;
    currentdate        DATE;
BEGIN
    SELECT
        value,
        current_mark_date,
        rule_reset,
        min_value,
        digit
    INTO
        svalue,scurrentmarkdate,rulreset,minval,digitnum
    FROM
        form_serial_number
    WHERE
        id = sid
    FOR UPDATE;

    IF
        ( svalue IS NULL )
    THEN
        svalue := 1;
    END IF;
    rnextval := svalue;
    currentdate := SYSDATE;
    currentyear := extract ( YEAR FROM currentdate );
    currentmonth := extract ( MONTH FROM currentdate );
    currentday := extract ( DAY FROM currentdate );
    markyear := extract ( YEAR FROM scurrentmarkdate );
    markmonth := extract ( MONTH FROM scurrentmarkdate );
    markday := extract ( DAY FROM scurrentmarkdate );


    IF
        ( ( ( rulreset = 1 ) AND ( currentyear != markyear ) ) OR ( ( rulreset = 2 ) AND ( currentyear != markyear OR currentmonth != markmonth ) ) OR ( ( rulreset = 3 ) AND ( currentyear
!= markyear OR currentmonth != markmonth OR currentday != markday ) ) )
    THEN
        IF
            ( minval IS NOT NULL )
        THEN
            rnextval := minval;
        ELSE
            rnextval := 1;
        END IF;
    END IF;

    IF
        ( readonly = 0 )
    THEN

        maxval := power(10,digitnum);
        IF
            ( rnextval >= ( maxval - 1 ) )
        THEN
            IF
                ( minval IS NULL )
            THEN
                todbval := 1;
            ELSE
                todbval := minval;
            END IF;

        ELSE
            todbval := rnextval + 1;
        END IF;

        UPDATE form_serial_number
            SET
                value = todbval,
                current_mark_date = currentdate
        WHERE
            id = sid;

    END IF;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END proc_nextserialnumber;
/

