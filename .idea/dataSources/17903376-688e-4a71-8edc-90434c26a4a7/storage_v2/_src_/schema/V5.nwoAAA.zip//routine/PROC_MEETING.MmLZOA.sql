CREATE procedure proc_meeting is
    -- 游标 从tb_user表取出所有usertype=12的用户id     field0001
    cursor rootnum is select field0001 from FORMMAIN_0027;
    r_rootnum b8.field0001%type;
    v_p number;
    begin
      --打开游标
      open rootnum;
      loop
        --遍历
        <<loop_block>>
        fetch rootnum into r_rootnum;
        EXIT WHEN rootnum%NOTFOUND;

        --插入测试表
        proc_meetting_check_delAndSave(r_rootnum);
        commit;
        goto loop_block;
        end loop;
        end;
/

